let s1 = {
	k: {
		k1: s,
		k2: 1
	}
};