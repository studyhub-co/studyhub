# Changelog

## 0.1.3 - 2018-10-25

- Updated extension to *yarn.lock* so that we no longer highlight *Gemfile.lock* files

## 0.1.2 - 2018-10-20

- Added screenshots to README

## 0.1.1 — 2018-10-20

- Added icon
- Added keywords

## 0.1.0 — 2018-10-20

- Initial release
