# CHANGELOG

## 0.1.7
### Fixed
* Match JSON colors to original theme ([#5](https://github.com/agirton/gloom/pull/5)) (@jorgegonzalez)

## 0.1.6
### Fixed
* Darken editor ruler, ([#1](https://github.com/agirton/gloom/pull/1)) (@tonyghita)
* Change lineHighlightBackground ([#3](https://github.com/agirton/gloom/pull/3)) (@corygibbons)

## 0.1.5
Fix issue where JSX tag was wrong color

## 0.1.4
Fix issue in CSS/Less where curly braces were same color as variable

## 0.1.3
Compatability update to editor foreground (brackets are brighter)

## 0.1.2
Compatability updates to regex and js

## 0.1.1
* Add Icon

## 0.1.0
* Initial release