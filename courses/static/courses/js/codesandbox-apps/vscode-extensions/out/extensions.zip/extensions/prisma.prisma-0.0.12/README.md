# vscode-prisma

Adds syntax highlighting, formatting, auto-completion, jump-to-definition and linting for `.prisma` files.

## Features

- Syntax highlighting
- Auto-formatting
- Auto-completion (_coming soon_)
- Jump-to-definition (_coming soon_)
- Liniting (_coming soon_)

## Preview

![](https://imgur.com/HbufPo6.png)

