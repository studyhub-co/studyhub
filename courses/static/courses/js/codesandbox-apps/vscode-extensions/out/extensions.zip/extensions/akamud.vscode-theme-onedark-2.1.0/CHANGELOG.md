The best rated One Dark port now includes Workbench theming!

## Version 2.1.0

* Peek window is now themed
* Badges colors are now consistent in every window

## Version 2.0.6

* Better contrast colors for sidebar sections, thanks to @fthebaud
* Fix "in" keyword in JS loops
* Fix JS template literals inconsistencies

## Version 2.0.5

* Fix Bash variables coloring

## Version 2.0.4

* Fix Rust Unsafe keyword
* Python coloring improvements
* Fix Notification background color
* Fix dropdown color
* Change extension buttons colors
* Fix Markdown raw block colors
* Fixes some JS and TS colors