/**
 * **Bold**
 * ```js
 * 1 + code
 * ```
 */
const a = 1