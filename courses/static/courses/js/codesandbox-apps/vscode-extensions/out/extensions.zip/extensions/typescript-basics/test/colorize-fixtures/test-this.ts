{
	this.foo = 9;
}