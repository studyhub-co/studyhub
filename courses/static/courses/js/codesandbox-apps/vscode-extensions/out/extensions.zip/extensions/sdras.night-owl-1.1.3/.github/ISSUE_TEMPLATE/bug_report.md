---
name: Bug report
about: Create a report to help us improve

---

**Please make sure you're using the latest version of the plugin before submitting an issue**

**Screenshots**
If applicable, add screenshots to help explain your problem, it helps us debug faster.

If you are submitting a bug report in a language not currently in demo folder, a PR to this folder with the language helps us track it down.

Thanks!
