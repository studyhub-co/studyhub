# yarn-lock-syntax

Syntax highlighting for *yarn.lock* files for Visual Studio Code.

## Screenshots

**Atom One Light** theme:

![yarn.lock file highlighted using the Atom One Light theme](https://raw.githubusercontent.com/mariusschulz/vscode-yarn-lock-syntax/master/screenshots/atom-one-light.png)

**Dracula** theme:

![yarn.lock file highlighted using the Dracula theme](https://raw.githubusercontent.com/mariusschulz/vscode-yarn-lock-syntax/master/screenshots/dracula.png)

**Monokai** theme:

![yarn.lock file highlighted using the Dracula theme](https://raw.githubusercontent.com/mariusschulz/vscode-yarn-lock-syntax/master/screenshots/monokai.png)
