# better-toml README

Better TOML is vs code extension to support TOML file.

## Features

- Syntax Hightlighting for `.toml` files

![Syntax Hightlighting](https://github.com/bungcip/better-toml/raw/master/images/feature_syntax_highlight.png)

- Syntax Validation for invalid input

![Syntax Validation](https://github.com/bungcip/better-toml/raw/master/images/feature_syntax_validation.gif)

- Syntax Hightligting for markdown frontmatter

![Frontmatter](https://github.com/bungcip/better-toml/raw/master/images/feature_frontmatter.gif)