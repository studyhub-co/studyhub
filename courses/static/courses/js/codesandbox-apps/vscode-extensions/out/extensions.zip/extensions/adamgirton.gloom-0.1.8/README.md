# VS Code Gloom

A dark and gloomy pastel color syntax theme for VS Code. Ported from [@hejrobin's](https://github.com/hejrobin) Atom [gloom](https://github.com/hejrobin/gloom)

---

# Changelog
[CHANGELOG.md](https://github.com/agirton/gloom/blob/master/CHANGELOG.md)

___
### Language &bull; `Markdown`
![Language: Markdown](https://raw.githubusercontent.com/agirton/gloom/master/screenshots/markdown.png)

### Language &bull; `Javascript`
![Language: Javascript](https://raw.githubusercontent.com/agirton/gloom/master/screenshots/javascript.png)
