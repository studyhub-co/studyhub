class A2 extends B1 {
	public count: number = 9;
	public resolveNextGeneration(cell : A2) {
	}
}