/**
 * @example
 * 1 + 1
 *
 * @other
 * not colored
 */
const a = 1