const validate = (correctData, userReactionData) => {
  // always return true, frontend validation for the game
  // TODO not so secure
  return true;
};