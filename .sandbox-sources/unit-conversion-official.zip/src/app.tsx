import React from "react";

import UnitConversion from "@studyhub.co/eval/lib/components/unitConversion";
import { theme } from "@studyhub.co/eval/lib/components/style";
import { ThemeProvider } from "@material-ui/styles";

// import { mockQaChoices } from "./mockData";

const App: React.FC = () => {
  const getMaterialUuid = () => {
    // /evaluation/03bc1a2d-febe-4a0b-9028-1957eed68bd2/03bc1a2d-febe-4a0b-9028-1957eed68bd2/
    const segments = document.location.pathname.split("/");
    let materiallUuid = undefined;
    if (segments.length > 3) {
      materiallUuid = segments[3];
    }
    return materiallUuid;
  };

  const [state, setState] = React.useState({
    checkedEditMode: false,
    currentMaterialUuid: getMaterialUuid()
  });

  const handleEditModeChange = () => (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setState({ ...state, checkedEditMode: event.target.checked });
  };

  const moveToNextComponent = (nextMaterialUuid: string | undefined) => {
    setState({ ...state, currentMaterialUuid: nextMaterialUuid });
  };

  const getLessonUuid = () => {
    // /evaluation/03bc1a2d-febe-4a0b-9028-1957eed68bd2/03bc1a2d-febe-4a0b-9028-1957eed68bd2/
    const segments = document.location.pathname.split("/");
    let lessonUuid = undefined;
    if (segments.length > 4) {
      lessonUuid = segments[4];
    }
    return lessonUuid;
  };

  return (
    <ThemeProvider theme={theme}>
      <div>Test</div>
      <div>
        <UnitConversion
          lessonUuid={getLessonUuid()}
          moveToNextComponent={moveToNextComponent}
          materialUuid={state.currentMaterialUuid}
        />
      </div>
    </ThemeProvider>
  );
};

export default App;