const validate = (correctData, userReactionData) => {
  // check that answers is correct
  return correctData.answer.expectedOutput === userReactionData.answer.expectedOutput;
};