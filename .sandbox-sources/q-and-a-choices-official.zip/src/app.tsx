import React from "react";

import Switch from "@material-ui/core/Switch";
import FormControlLabel from "@material-ui/core/FormControlLabel";

import QAChoices from "@studyhub.co/eval/lib/components/qaChoices";
import { theme } from "@studyhub.co/eval/lib/components/style";
import { ThemeProvider } from "@material-ui/styles";

// import { mockQaChoices } from "./mockData";

const App: React.FC = () => {
  const getMaterialUuid = () => {
    // /evaluation/03bc1a2d-febe-4a0b-9028-1957eed68bd2/03bc1a2d-febe-4a0b-9028-1957eed68bd2/
    const segments = document.location.pathname.split("/");
    let materiallUuid = undefined;
    if (segments.length > 3) {
      materiallUuid = segments[3];
    }
    return materiallUuid;
  };

  const [state, setState] = React.useState({
    checkedEditMode: false,
    // previousMaterialUuid: null,
    currentMaterialUuid: getMaterialUuid()
  });

  const handleEditModeChange = () => (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setState({ ...state, checkedEditMode: event.target.checked });
  };

  const moveToNextComponent = (nextMaterialUuid: any) => {
    setState({ ...state, currentMaterialUuid: nextMaterialUuid });
  };

  // const moveToNextComponent = (lessonUuid, nextMaterialUuid) => {
  //   window.parent.postMessage(
  //     {
  //       type: "redirect_to_material",
  //       data: { lessonUuid, nextMaterialUuid }
  //     },
  //     "*"
  //   );
  //   setState({ ...state, currentMaterialUuid: nextMaterialUuid });
  // };

  const getLessonUuid = () => {
    // /evaluation/03bc1a2d-febe-4a0b-9028-1957eed68bd2/03bc1a2d-febe-4a0b-9028-1957eed68bd2/
    const segments = document.location.pathname.split("/");
    let lessonUuid = undefined;
    if (segments.length > 4) {
      lessonUuid = segments[4];
    }
    return lessonUuid;
  };

  return (
    <ThemeProvider theme={theme}>
      <div>
        <QAChoices
          lessonUuid={getLessonUuid()}
          // previousMaterialUuid={state.previousMaterialUuid}
          moveToNextComponent={moveToNextComponent}
          materialUuid={state.currentMaterialUuid}
          // editMode={state.checkedEditMode}
          // componentData={mockQaChoicesMaterial.data}
        />
      </div>
    </ThemeProvider>
  );
};

export default App;