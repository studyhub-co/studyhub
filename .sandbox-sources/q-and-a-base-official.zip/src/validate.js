const validate = (correctData, userReactionData) => {
  // check that answers is correct
  return (
    correctData.answer.content.evaluatedMathText === userReactionData.answer.content.evaluatedMathText
  );
};